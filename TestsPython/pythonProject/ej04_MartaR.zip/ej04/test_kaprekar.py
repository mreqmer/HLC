from Ejercicio04 import kaprekar

def test_kaprekar():
    assert kaprekar(7641) == 1
    assert kaprekar(3524) == 3
    assert kaprekar(1111) == 8



